# Shivaraj Maratha PWA — Hostinger deployment

- **Live URL:** https://pwa.digitalji.in/
- **Upload target:** `public_html/PWA/` (this is the domain document root)
- The package is a static build: the frontend is served from the **root of this
  document root**, so all asset URLs start with `/` (`/assets/...`, `/favicon.png`).

## 1. Upload & extract

1. hPanel → **Files → File Manager** → open `public_html/PWA/`.
2. Upload `shivaraj-maratha-pwa-hostinger.zip`.
3. Right-click → **Extract** into that same folder.
4. Turn on **Show hidden files** and make sure `.htaccess` sits directly beside
   `index.html`.
5. Delete the zip afterwards.

Resulting structure (must match):

```text
public_html/PWA/
├── .htaccess
├── index.html
├── favicon.ico
├── favicon.png
├── apple-touch-icon.png
├── manifest.webmanifest
├── sw.js
├── workbox-2fbc6a65.js
├── assets/            (compiled .js / .css, logo)
└── icons/             (PWA icons)
```

## 2. Enable HTTPS (required for the PWA)

hPanel → **Security → SSL** → install the free Let's Encrypt certificate for
`pwa.digitalji.in`, then enable **Force HTTPS**. Service workers and "Add to Home
screen" only work over HTTPS.

## 3. Verify after upload

- `https://pwa.digitalji.in/` loads the app (not blank).
- View source: it references `<script ... src="/assets/index-*.js">` — **not** `/src/main.tsx`.
- `https://pwa.digitalji.in/assets/index-*.js` → **Content-Type: application/javascript**.
- `https://pwa.digitalji.in/favicon.png` → 200.
- `https://pwa.digitalji.in/manifest.webmanifest` → 200.
- Deep links `…/home` and `…/shortlist` load, and survive a hard refresh.
- `…/api/anything` returns 404 (the SPA must not swallow API paths).

## 4. Backend

**Not included in this package.** The frontend calls the API on a **separate
origin** (`https://shivrajmaratha.com/apis`). Never place the Laravel `backend/`
folder (or its `.env`) inside this document root — that would expose secrets.
If the API is later served from this host, deploy it separately and configure its
`.env` on the server.

## 5. Environment / build mode

This build was produced with `VITE_ENABLE_DEV_PREVIEW=true` (demo mode) so the
authenticated screens preview like local. For the real launch, remove
`frontend/.env.production.local`, ensure the API base URL is final, then rebuild:

```bash
cd frontend && npm ci && npm run build
```

and repackage the contents of `frontend/dist/`.
